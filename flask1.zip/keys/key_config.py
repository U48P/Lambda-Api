#Temporär

aws_access_key_id="AKIAWL3JKJKBETB6DPPA",
aws_secret_access_key= "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",
                 